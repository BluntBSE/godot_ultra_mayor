# ScriptNameOnTop

This Godot 4.0 plugin will benefit those who hide the Scripts Panel for the sake of improved screen space.

- Currently opened script's name is listed at the top of the script editor. You can click it for a drop-down list of recently opened scripts.

It also includes two tangentially related features:

- Bottom of Script Editor is auto-hidden for even more screen space. It shows itself when needed.

- SceneTree highlights the script icon(s) for the opened script.

![Untitled](https://user-images.githubusercontent.com/15337628/196391599-4cf0336d-8e8a-4d22-84db-7ae46146d697.png)
